import os
os.system("./build/linux/helpdesk_app_flet")